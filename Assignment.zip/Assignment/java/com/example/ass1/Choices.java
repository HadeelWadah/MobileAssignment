package com.example.ass1;

import java.util.ArrayList;
import java.util.List;

public class Choices {
    private final List<Items> selectedItems;

    public Choices() {
        this.selectedItems = new ArrayList<>();
    }

    public void addItem(Items newItem) {
        if (newItem == null) return;

        for (Items item : selectedItems) {
            if (item.getId() == newItem.getId()) {
                item.increaseQuantity();
                return;
            }
        }

        selectedItems.add(new Items(newItem));
    }

    public boolean removeItem(Items itemToRemove) {
        if (itemToRemove == null) return false;
        return selectedItems.removeIf(item -> item.getId() == itemToRemove.getId());
    }

    public boolean updateQuantity(int itemId, int newQuantity, Items availableItem) {
        if (newQuantity <= 0 || availableItem == null ||
                availableItem.getStockQuantity() < newQuantity) {
            return false;
        }

        for (Items item : selectedItems) {
            if (item.getId() == itemId) {
                int oldQuantity = item.getQuantity();
                item.setQuantity(newQuantity);
                availableItem.increaseStock(oldQuantity - newQuantity);
                return true;
            }
        }
        return false;
    }
    public List<Items> getSelectedItems() {
        return new ArrayList<>(selectedItems);
    }
    public double calculateTotalPrice() {
        double total = 0.0;
        for (Items item : selectedItems) {
            total += item.getTotalPrice();
        }
        return total;
    }
    public void clear() {
        selectedItems.clear();
    }
    public int getTotalItemsCount() {
        int count = 0;
        for (Items item : selectedItems) {
            count += item.getQuantity();
        }
        return count;
    }
    public boolean isEmpty() {

        return selectedItems.isEmpty();
    }
}