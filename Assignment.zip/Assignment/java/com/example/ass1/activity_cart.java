package com.example.ass1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.Locale;

public class activity_cart extends AppCompatActivity {

    private LinearLayout productsContainer;
    private TextView totalPriceTextView;
    private Button checkoutButton;
    private Driver driver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        driver = Driver.getInstance(getApplicationContext());

        initializeViews();
        setupCheckoutButton();
        refreshCart();
    }

    private void initializeViews() {
        productsContainer = findViewById(R.id.productsContainer);
        totalPriceTextView = findViewById(R.id.totalPriceTextView);
        checkoutButton = findViewById(R.id.checkoutButton);
    }

    private void setupCheckoutButton() {
        checkoutButton.setOnClickListener(v -> handleCheckout());
    }

    private void handleCheckout() {
        if (driver.getCartItems().isEmpty()) {
            navigateToMainActivity3();
        } else {
            completePurchase();
        }
    }

    private void navigateToMainActivity3() {
        startActivity(new Intent(this, MainActivity3.class));
        finish();
    }

    private void completePurchase() {
        try {
            driver.completePurchase();
            Toast.makeText(this, "تم إتمام الشراء بنجاح", Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception e) {
            Log.e("CartActivity", "Checkout error", e);
            Toast.makeText(this, "حدث خطأ أثناء إتمام الشراء", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshCart() {
        productsContainer.removeAllViews();
        List<Items> cartItems = driver.getCartItems();

        if (cartItems.isEmpty()) {
            showEmptyCartMessage();
            return;
        }

        for (Items item : cartItems) {
            addCartItemView(item);
        }

        updateTotalPrice();
    }

    private void showEmptyCartMessage() {
        TextView emptyText = new TextView(this);
        emptyText.setText("عربة التسوق فارغة");
        emptyText.setTextSize(18);
        productsContainer.addView(emptyText);
        totalPriceTextView.setText("المجموع: 0.00 د.أ");
    }

    private void addCartItemView(Items item) {
        LinearLayout itemLayout = createItemLayout();

        TextView nameText = createTextView(item.getName(), 18);
        TextView priceText = createTextView(
                String.format(Locale.getDefault(), "السعر: %.2f د.أ", item.getPrice()),
                16
        );

        TextView quantityText = createTextView(
                "الكمية: " + item.getQuantity(),
                16
        );

        LinearLayout buttonsLayout = createQuantityButtons(item, quantityText);

        itemLayout.addView(nameText);
        itemLayout.addView(priceText);
        itemLayout.addView(quantityText);
        itemLayout.addView(buttonsLayout);

        productsContainer.addView(itemLayout);
    }

    private LinearLayout createItemLayout() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(
                dpToPx(10),
                dpToPx(10),
                dpToPx(10),
                dpToPx(30)
        );
        return layout;
    }

    private TextView createTextView(String text, float textSize) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextSize(textSize);
        return textView;
    }

    private LinearLayout createQuantityButtons(Items item, TextView quantityText) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);

        Button decreaseBtn = createButton("-", v -> {
            if (item.getQuantity() > 1) {
                item.decreaseQuantity();
                quantityText.setText("الكمية: " + item.getQuantity());
            } else {
                driver.removeFromCart(item);
                refreshCart();
            }
            updateTotalPrice();
        });

        Button increaseBtn = createButton("+", v -> {
            if (item.getStockQuantity() > item.getQuantity()) {
                item.increaseQuantity();
                quantityText.setText("الكمية: " + item.getQuantity());
                updateTotalPrice();
            } else {
                Toast.makeText(this, "لا يوجد مخزون كافي", Toast.LENGTH_SHORT).show();
            }
        });

        layout.addView(decreaseBtn);
        layout.addView(increaseBtn);

        return layout;
    }

    private Button createButton(String text, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text);
        button.setOnClickListener(listener);
        return button;
    }

    private void updateTotalPrice() {
        double total = driver.calculateTotal();
        totalPriceTextView.setText(
                String.format(Locale.getDefault(), "المجموع: %.2f د.أ", total)
        );
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshCart();
    }
}