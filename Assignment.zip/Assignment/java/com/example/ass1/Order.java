package com.example.ass1;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class Order {
    private static int nextId = 1;
    private final String orderId;
    private final int id;
    private final Date orderDate;
    private final List<Items> items;
    private final User user;
    private double totalPrice;
    private String status;
    private String paymentMethod;
    private String shippingAddress;

    public Order(List<Items> items, User user) {
        this.orderId = generateOrderId();
        this.id = nextId++;
        this.orderDate = new Date();
        this.items = new ArrayList<>(items);
        this.user = user;
        this.totalPrice = calculateTotal();
        this.status = "قيد المعالجة";
        this.paymentMethod = "الدفع عند الاستلام";
        this.shippingAddress = user.getCity();
    }
    public String getOrderId() { return orderId; }
    public int getId() { return id; }
    public Date getOrderDate() { return orderDate; }
    public List<Items> getItems() { return new ArrayList<>(items); }
    public User getUser() { return user; }
    public double getTotalPrice() { return totalPrice; }
    public String getStatus() { return status; }
    public String getPaymentMethod() { return paymentMethod; }
    public String getShippingAddress() { return shippingAddress; }

    private String generateOrderId() {
        return "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    private double calculateTotal() {
        double total = 0.0;
        for (Items item : items) {
            total += item.getTotalPrice();
        }
        return total;
    }

    public void completeOrder() {
        this.status = "مكتمل";
    }

    public void cancelOrder() {
        this.status = "ملغى";
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public boolean canBeCancelled() {
        return status.equals("قيد المعالجة");
    }

    public void setPaymentMethod(String method) {
        this.paymentMethod = method;
    }

    public void setShippingAddress(String address) {
        this.shippingAddress = address;
    }

    public String getFormattedDate() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(orderDate);
    }

    public String getOrderSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append("رقم الطلب: ").append(orderId).append("\n");
        summary.append("التاريخ: ").append(getFormattedDate()).append("\n");
        summary.append("الحالة: ").append(status).append("\n\n");
        summary.append("المنتجات:\n");

        for (Items item : items) {
            summary.append("- ").append(item.getName())
                    .append(" (×").append(item.getQuantity()).append(")")
                    .append(": ").append(item.getTotalPrice()).append(" ر.س\n");
        }

        summary.append("\nالمجموع: ").append(totalPrice).append(" ر.س\n");
        summary.append("طريقة الدفع: ").append(paymentMethod).append("\n");
        summary.append("عنوان التوصيل: ").append(shippingAddress).append("\n\n");
        summary.append("معلومات العميل:\n");
        summary.append(user.getFirstName()).append(" ").append(user.getLastName()).append("\n");
        summary.append(user.getPhone()).append("\n");
        summary.append(user.getCity());

        return summary.toString();
    }
    public String toStorageString() {
        StringBuilder sb = new StringBuilder();
        sb.append(orderId).append(",")
                .append(id).append(",")
                .append(orderDate.getTime()).append(",")
                .append(status).append(",")
                .append(paymentMethod).append(",")
                .append(shippingAddress).append(",")
                .append(totalPrice);
        return sb.toString();
    }

    @Override
    public String toString() {
        return "Order #" + orderId + " - " + getFormattedDate() + " - " + totalPrice + " ر.س";
    }
}