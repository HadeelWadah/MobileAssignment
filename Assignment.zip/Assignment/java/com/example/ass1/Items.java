package com.example.ass1;

public class Items {
    private final int id;
    private final String name;
    private final String description;
    private final double price;
    private int quantity;
    private int stockQuantity;
    public Items(int id, String name, String description, double price, int stockQuantity) {
        if (id <= 0) throw new IllegalArgumentException("ID must be positive");
        if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Name cannot be empty");
        if (price < 0) throw new IllegalArgumentException("Price cannot be negative");
        if (stockQuantity < 0) throw new IllegalArgumentException("Stock quantity cannot be negative");

        this.id = id;
        this.name = name.trim();
        this.description = description != null ? description.trim() : "";
        this.price = price;
        this.quantity = 1;
        this.stockQuantity = stockQuantity;
    }

    public Items(Items item) {
        this(item.id, item.name, item.description, item.price, item.stockQuantity);
        this.quantity = item.quantity;
    }

    // ============ Getters ============
    public int getId() { return id; }
    public int getStockQuantity() { return stockQuantity; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }

    public boolean decreaseStock(int amount) {
        if (amount <= 0 || amount > stockQuantity) {
            return false;
        }
        stockQuantity -= amount;
        return true;
    }
    public void increaseStock(int amount) {
        if (amount > 0) {
            stockQuantity += amount;
        }
    }


    public void setQuantity(int newQuantity) {
        if (newQuantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        this.quantity = newQuantity;
    }
    public double getTotalPrice() {
        return price * quantity;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Items item = (Items) o;
        return id == item.id;
    }
    public void increaseQuantity() {
        if (stockQuantity > quantity) {
            quantity++;
        }
    }

    public void decreaseQuantity() {
        if (quantity > 1) {
            quantity--;
        }
    }

    @Override
    public int hashCode() {
        return id;
    }
    public static Items fromStorageString(String str) {
        try {
            String[] parts = str.split(",");
            if (parts.length >= 5) {
                return new Items(
                        Integer.parseInt(parts[0]),
                        parts[1],
                        parts[2],
                        Double.parseDouble(parts[3]),
                        Integer.parseInt(parts[4])
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public String toStorageString() {
        return id + "," + name + "," + description + "," + price + "," + stockQuantity;
    }
}