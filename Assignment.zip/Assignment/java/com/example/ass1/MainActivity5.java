package com.example.ass1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class MainActivity5 extends AppCompatActivity {

    private Driver driver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main5);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        driver = Driver.getInstance(getApplicationContext());
        setupViews();
    }

    private void setupViews() {
        // زر الرجوع
        findViewById(R.id.imageView7).setOnClickListener(v -> finishWithAnimation());

        // أزرار الإضافة إلى السلة
        setupAddToCartButton(R.id.addBtn4, "مرطب شفاه");
        setupAddToCartButton(R.id.addBtn5, "لمعان شفاه");
        setupAddToCartButton(R.id.addBtn6, "قلم تحديد الشفاه");

        // صور المنتجات لعرض التفاصيل
        setupProductDetails(R.id.imageView4, "مرطب شفاه");
        setupProductDetails(R.id.imageView5, "لمعان شفاه");
        setupProductDetails(R.id.imageView6, "قلم تحديد الشفاه");
    }

    private void finishWithAnimation() {
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void setupAddToCartButton(int buttonId, String productName) {
        Button button = findViewById(buttonId);
        if (button != null) {
            button.setOnClickListener(v -> handleAddToCart(productName));
        }
    }

    private void setupProductDetails(int imageViewId, String productName) {
        ImageView imageView = findViewById(imageViewId);
        if (imageView != null) {
            imageView.setOnClickListener(v -> showProductInfo(productName));
        }
    }

    private void handleAddToCart(String productName) {
        try {
            Items product = driver.findItemByName(productName);
            if (product == null) {
                showToast("المنتج غير متوفر");
                return;
            }

            if (driver.addToCart(product, 1)) {
                showCartUpdateMessage(product);
            } else {
                showToast("الكمية غير متوفرة في المخزون");
            }
        } catch (Exception e) {
            Log.e("MainActivity5", "Add to cart error", e);
            showToast("خطأ في إضافة المنتج");
        }
    }

    private void showCartUpdateMessage(Items product) {
        int quantityInCart = 0;
        for (Items item : driver.getCartItems()) {
            if (item.getId() == product.getId()) {
                quantityInCart = item.getQuantity();
                break;
            }
        }

        String message = String.format(Locale.getDefault(),
                "تمت إضافة %s%nالكمية: %d%nالمخزون: %d",
                product.getName(),
                quantityInCart,
                product.getStockQuantity());

        showToast(message);
    }

    private void showProductInfo(String productName) {
        Items product = driver.findItemByName(productName);
        if (product != null) {
            // عرض التفاصيل في MainActivity3
            Intent intent = new Intent(this, MainActivity3.class);
            intent.putExtra("product_details", new String[]{
                    product.getName(),
                    String.valueOf(product.getPrice()),
                    String.valueOf(product.getStockQuantity()),
                    product.getDescription()
            });
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } else {
            showToast("تفاصيل المنتج غير متاحة");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}