package com.example.ass1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    private EditText firstNameEditText, lastNameEditText, phoneEditText, cityEditText;
    private TextView firstNameError, lastNameError, phoneError, cityError;
    private Button submitButton;

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        initializeViews();
        setupSharedPrefs();
        loadSavedData(); // تحميل البيانات المحفوظة
        setupButtonClick();
    }

    private void initializeViews() {
        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        cityEditText = findViewById(R.id.cityEditText);

        firstNameError = findViewById(R.id.firstNameError);
        lastNameError = findViewById(R.id.lastNameError);
        phoneError = findViewById(R.id.phoneError);
        cityError = findViewById(R.id.cityError);

        submitButton = findViewById(R.id.submitButton);

        // إخفاء جميع رسائل الخطأ عند البدء
        hideAllErrors();
    }

    private void setupSharedPrefs() {
        prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
    }

    private void loadSavedData() {
        firstNameEditText.setText(prefs.getString("firstName", ""));
        lastNameEditText.setText(prefs.getString("lastName", ""));
        phoneEditText.setText(prefs.getString("phoneNumber", ""));
        cityEditText.setText(prefs.getString("city", ""));
    }

    private void hideAllErrors() {
        firstNameError.setVisibility(View.GONE);
        lastNameError.setVisibility(View.GONE);
        phoneError.setVisibility(View.GONE);
        cityError.setVisibility(View.GONE);
    }

    private void setupButtonClick() {
        submitButton.setOnClickListener(v -> {
            String firstName = firstNameEditText.getText().toString().trim();
            String lastName = lastNameEditText.getText().toString().trim();
            String phoneNumber = phoneEditText.getText().toString().trim();
            String city = cityEditText.getText().toString().trim();

            hideAllErrors();
            boolean isValid = validateInputs(firstName, lastName, phoneNumber, city);

            if (isValid) {
                saveUserData(firstName, lastName, phoneNumber, city);
                navigateToNextActivity(firstName, lastName, phoneNumber, city);
            }
        });
    }

    private boolean validateInputs(String firstName, String lastName, String phoneNumber, String city) {
        boolean isValid = true;

        if (firstName.isEmpty()) {
            firstNameError.setText("الاسم الأول مطلوب");
            firstNameError.setVisibility(View.VISIBLE);
            isValid = false;
        }

        if (lastName.isEmpty()) {
            lastNameError.setText("الاسم الأخير مطلوب");
            lastNameError.setVisibility(View.VISIBLE);
            isValid = false;
        }

        if (phoneNumber.isEmpty()) {
            phoneError.setText("رقم الهاتف مطلوب");
            phoneError.setVisibility(View.VISIBLE);
            isValid = false;
        } else if (!isValidPhoneNumber(phoneNumber)) {
            phoneError.setText("يجب أن يبدأ الرقم بـ 05 ويتكون من 10 أرقام");
            phoneError.setVisibility(View.VISIBLE);
            isValid = false;
        }

        if (city.isEmpty()) {
            cityError.setText("المدينة مطلوبة");
            cityError.setVisibility(View.VISIBLE);
            isValid = false;
        }

        return isValid;
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber.matches("05\\d{8}");
    }

    private void saveUserData(String firstName, String lastName, String phoneNumber, String city) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("firstName", firstName);
        editor.putString("lastName", lastName);
        editor.putString("phoneNumber", phoneNumber);
        editor.putString("city", city);
        editor.apply();
    }

    private void navigateToNextActivity(String firstName, String lastName, String phoneNumber, String city) {
        Intent intent = new Intent(this, MainActivity3.class);
        intent.putExtra("EXTRA_FIRST_NAME", firstName);
        intent.putExtra("EXTRA_LAST_NAME", lastName);
        intent.putExtra("EXTRA_PHONE", phoneNumber);
        intent.putExtra("EXTRA_SHIPPING_AREA", city);
        startActivity(intent);
    }
}