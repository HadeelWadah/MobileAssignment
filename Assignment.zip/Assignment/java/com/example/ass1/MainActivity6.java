package com.example.ass1;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.Locale;

public class MainActivity6 extends AppCompatActivity {

    private Driver driver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        driver = Driver.getInstance(getApplicationContext());
        setupClickListeners();
    }

    private void setupClickListeners() {
        ImageView backButton = findViewById(R.id.bottomImage);
        if (backButton != null) {
            backButton.setOnClickListener(v -> finish());
        }

        setupPerfumeButtons();
    }

    private void setupPerfumeButtons() {
        setupPerfumeButton(R.id.addPerfume1, "عطر لطافة", R.id.perfume1);
        setupPerfumeButton(R.id.addPerfume2, "عطر صبايا", R.id.perfume2);
        setupPerfumeButton(R.id.addPerfume3, "عطر وشوشة", R.id.perfume3);
    }

    private void setupPerfumeButton(int buttonId, String perfumeName, int imageViewId) {
        Button button = findViewById(buttonId);
        ImageView imageView = findViewById(imageViewId);

        if (button != null) {
            button.setOnClickListener(v -> addPerfumeToCart(perfumeName));
        }

        if (imageView != null) {
            imageView.setOnClickListener(v -> showProductDetails(perfumeName));
        }
    }

    private void addPerfumeToCart(String perfumeName) {
        try {
            Items perfume = driver.findItemByName(perfumeName);
            if (perfume == null) {
                showToast("المنتج غير متوفر");
                return;
            }

            if (driver.addToCart(perfume, 1)) {
                updateCartMessage(perfume);
            } else {
                showToast("لا يوجد كمية كافية في المخزون");
            }
        } catch (Exception e) {
            Log.e("MainActivity6", "Error adding to cart", e);
            showToast("حدث خطأ أثناء الإضافة");
        }
    }

    private void updateCartMessage(Items item) {
        int quantity = 0;
        for (Items cartItem : driver.getCartItems()) {
            if (cartItem.getId() == item.getId()) {
                quantity = cartItem.getQuantity();
                break;
            }
        }

        String message = String.format(Locale.getDefault(),
                "تمت إضافة %s\nالكمية: %d\nالمخزون: %d",
                item.getName(), quantity, item.getStockQuantity());

        showToast(message);
    }

    private void showProductDetails(String perfumeName) {
        Items item = driver.findItemByName(perfumeName);
        if (item != null) {
            String details = String.format(Locale.getDefault(),
                    "اسم المنتج: %s\nالسعر: %.2f ر.س\nالكمية المتاحة: %d\n\n%s",
                    item.getName(),
                    item.getPrice(),
                    item.getStockQuantity(),
                    item.getDescription());

            showLongToast(details);
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void showLongToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}