package com.example.ass1;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity4 extends AppCompatActivity {

    private Driver driver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        try {
            driver = Driver.getInstance(getApplicationContext());
            if (driver == null) {
                throw new IllegalStateException("Driver initialization failed");
            }
        } catch (Exception e) {
            Log.e("MainActivity4", "Driver init error", e);
            Toast.makeText(this, "System initialization error", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        setupViews();
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            if (driver != null) {
                driver.loadCartData();
            }
        } catch (Exception e) {
            Log.e("MainActivity4", "Cart load error", e);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveData();
    }

    private void saveData() {
        try {
            if (driver != null) {
                driver.saveProductsData();
                driver.saveCartData();
            }
        } catch (Exception e) {
            Log.e("MainActivity4", "Data save error", e);
        }
    }

    private void setupViews() {
        ImageView backButton = findViewById(R.id.imageView);
        if (backButton != null) {
            backButton.setOnClickListener(v -> finish());
        }

        setupProductButtons();
    }

    private void setupProductButtons() {
        int[] buttonIds = {R.id.addBtn1, R.id.addBtn2, R.id.addBtn3};
        String[] productNames = {
                "كريم مرطب للبشرة",
                "مقشر طبيعي",
                "غسول بيبي باودر"
        };

        for (int i = 0; i < buttonIds.length; i++) {
            Button button = findViewById(buttonIds[i]);
            if (button != null) {
                String productName = productNames[i];
                button.setOnClickListener(v -> handleProductAdd(productName));
            }
        }
    }

    private void handleProductAdd(String productName) {
        try {
            if (driver == null) {
                showToast("System not initialized");
                return;
            }

            Items product = driver.findItemByName(productName);
            if (product == null) {
                showToast("Product not found");
                return;
            }

            if (driver.addToCart(product, 1)) {
                showProductAddedMessage(product);
            } else {
                showToast("Cannot add product - insufficient stock");
            }
        } catch (Exception e) {
            Log.e("MainActivity4", "Add product error", e);
            showToast("Error adding product");
        }
    }

    private void showProductAddedMessage(Items product) {
        try {
            if (driver == null || product == null) return;

            int quantityInCart = 0;
            List<Items> cartItems = driver.getCartItems();
            for (Items item : cartItems) {
                if (item.getId() == product.getId()) {
                    quantityInCart = item.getQuantity();
                    break;
                }
            }

            String message = String.format(
                    "Added: %s\nIn cart: %d\nRemaining: %d",
                    product.getName(),
                    quantityInCart,
                    product.getStockQuantity()
            );
            showToast(message);
        } catch (Exception e) {
            Log.e("MainActivity4", "Show message error", e);
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}