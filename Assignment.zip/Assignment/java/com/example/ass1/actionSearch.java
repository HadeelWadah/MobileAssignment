package com.example.ass1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;
import java.util.Locale;

public class actionSearch extends AppCompatActivity {

    private EditText searchEditText;
    private Button searchButton;
    private Driver driver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_action_search);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Driver with application context
        driver = Driver.getInstance(getApplicationContext());

        searchEditText = findViewById(R.id.searchEditText);
        searchButton = findViewById(R.id.searchButton);

        if (searchButton != null && searchEditText != null) {
            searchButton.setOnClickListener(v -> performSearch());
        }
    }

    private void performSearch() {
        try {
            String query = searchEditText.getText().toString().trim();

            if (query.isEmpty()) {
                showToast("الرجاء إدخال كلمة البحث");
                return;
            }

            List<Items> results = driver.searchProducts(query);

            if (results == null || results.isEmpty()) {
                showToast("لا توجد نتائج مطابقة");
                return;
            }

            openRelevantActivity(results.get(0));
        } catch (Exception e) {
            Log.e("actionSearch", "Search error", e);
            showToast("حدث خطأ أثناء البحث");
        }
    }

    private void openRelevantActivity(Items item) {
        if (item == null) {
            showToast("خطأ في بيانات المنتج");
            return;
        }

        try {
            String category = driver.getProductCategory(item.getId());
            Intent intent;

            switch (category) {
                case "skin_care":
                    intent = new Intent(this, MainActivity4.class);
                    break;
                case "lip_care":
                    intent = new Intent(this, MainActivity5.class);
                    break;
                case "perfume":
                    intent = new Intent(this, MainActivity6.class);
                    break;
                default:
                    showToast("القسم غير معروف");
                    return;
            }

            intent.putExtra("product_id", item.getId());
            intent.putExtra("product_name", item.getName());
            intent.putExtra("product_price", item.getPrice());

            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } catch (Exception e) {
            Log.e("actionSearch", "Activity navigation error", e);
            showToast("حدث خطأ أثناء فتح الصفحة");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}