package com.example.ass1;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.preference.PreferenceManager;
import java.util.ArrayList;
import java.util.List;

public class Driver {
    private static volatile Driver instance;
    private final List<Items> availableItems;
    private final Choices currentChoices;
    private User currentUser;
    private final List<Order> orders;
    private static final String PREFS_NAME = "ShopAppPrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_REMEMBER_ME = "remember_me";
    private static final String KEY_CART_ITEMS = "cart_items";
    private static final String KEY_CART_QUANTITIES = "cart_quantities";
    private static final String KEY_PRODUCTS = "products_data";
    private static final String KEY_STOCKS = "products_stocks";
    public static final String CART_ITEMS_IDS = "CART_ITEMS_IDS";
    public static final String CART_ITEMS_QUANTITIES = "CART_ITEMS_QUANTITIES";

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    private Context context;

    private final SharedPreferences sharedPreferences;

    private Driver(Context context) {
        this.context = context.getApplicationContext();
        this.sharedPreferences = this.context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.availableItems = new ArrayList<>();
        this.currentChoices = new Choices();
        this.orders = new ArrayList<>();
        this.context = context.getApplicationContext();
        setupSharedPrefs();

        initializeAvailableItems();
        loadUserData();
        loadProductsData();
        loadCartData();
    }
    private void setupSharedPrefs() {
        prefs = PreferenceManager.getDefaultSharedPreferences(context); // تأكد أن `context` مُمرر أو مُهيأ
        editor = prefs.edit();
    }
    public void loadCartData() {
        if (!prefs.contains(CART_ITEMS_IDS)) {
            return;
        }
        String itemsIdsStr = prefs.getString(CART_ITEMS_IDS, "");
        String quantitiesStr = prefs.getString(CART_ITEMS_QUANTITIES, "");

        String[] itemIds = itemsIdsStr.split(",");
        String[] quantities = quantitiesStr.split(",");

        if (itemIds.length != quantities.length) {
            return;
        }

        currentChoices.clear();
        for (int i = 0; i < itemIds.length; i++) {
            try {
                int itemId = Integer.parseInt(itemIds[i]);
                int quantity = Integer.parseInt(quantities[i]);

                Items item = findItemById(itemId);
                if (item != null && item.getStockQuantity() >= quantity) {
                    Items cartItem = new Items(item);
                    cartItem.setQuantity(quantity);
                    currentChoices.addItem(cartItem);
                }
            } catch (NumberFormatException e) {
                continue;
            }
        }
    }
    public void saveCartData() {
        StringBuilder itemsIds = new StringBuilder();
        StringBuilder quantities = new StringBuilder();

        for (Items item : currentChoices.getSelectedItems()) {
            itemsIds.append(item.getId()).append(",");
            quantities.append(item.getQuantity()).append(",");
        }
        editor.putString(CART_ITEMS_IDS, itemsIds.toString());
        editor.putString(CART_ITEMS_QUANTITIES, quantities.toString());
        editor.commit();
    }



    public void saveProductsData() {
        if (sharedPreferences == null) {
            Log.e("Driver", "SharedPreferences is null");
            return;
        }

        try {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            StringBuilder productsData = new StringBuilder();
            StringBuilder stocksData = new StringBuilder();

            for (Items item : availableItems) {
                productsData.append(item.getId()).append(",")
                        .append(item.getName()).append(",")
                        .append(item.getDescription()).append(",")
                        .append(item.getPrice()).append(";");

                stocksData.append(item.getId()).append(",")
                        .append(item.getStockQuantity()).append(";");
            }

            editor.putString(KEY_PRODUCTS, productsData.toString());
            editor.putString(KEY_STOCKS, stocksData.toString());
            editor.apply();
        } catch (Exception e) {
            Log.e("Driver", "Error saving products data", e);
        }
    }

    public static Driver getInstance(Context context) {
        if (instance == null) {
            synchronized (Driver.class) {
                if (instance == null) {
                    instance = new Driver(context);
                }
            }
        }
        return instance;
    }

    // ================= User Management =================
    public void saveUserData() {
        try {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            if (currentUser != null) {
                editor.putString(KEY_USERNAME, currentUser.getUsername());
                editor.putString(KEY_EMAIL, currentUser.getEmail());
            }
            editor.apply();
        } catch (Exception e) {
            Log.e("Driver", "Error saving user data", e);
        }
    }


    public void loadUserData() {
        try {
            String username = sharedPreferences.getString(KEY_USERNAME, null);
            String email = sharedPreferences.getString(KEY_EMAIL, null);

            if (username != null && email != null) {
                this.currentUser = new User(username, email);
            }
        } catch (Exception e) {
            Log.e("Driver", "Error loading user data", e);
        }
    }

    public void setUser(User user, boolean rememberMe) {
        this.currentUser = user;
        try {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(KEY_REMEMBER_ME, rememberMe);
            editor.apply();
            if (rememberMe) {
                saveUserData();
            }
        } catch (Exception e) {
            Log.e("Driver", "Error setting user", e);
        }
    }

    public boolean shouldRememberUser() {
        return sharedPreferences.getBoolean(KEY_REMEMBER_ME, false);
    }


    public void logout() {
        try {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.remove(KEY_USERNAME);
            editor.remove(KEY_EMAIL);
            editor.remove(KEY_REMEMBER_ME);
            editor.apply();
            this.currentUser = null;
            this.currentChoices.clear();
        } catch (Exception e) {
            Log.e("Driver", "Error during logout", e);
        }
    }



    public void clearCart() {
        currentChoices.clear();
        saveCartData();
    }


    public void loadProductsData() {
        try {
            String productsStr = sharedPreferences.getString(KEY_PRODUCTS, "");
            String stocksStr = sharedPreferences.getString(KEY_STOCKS, "");

            if (!productsStr.isEmpty()) {
                availableItems.clear();
                String[] products = productsStr.split(";");

                for (String product : products) {
                    if (!product.isEmpty()) {
                        String[] parts = product.split(",");
                        if (parts.length >= 4) {
                            int id = Integer.parseInt(parts[0]);
                            String name = parts[1];
                            String desc = parts[2];
                            double price = Double.parseDouble(parts[3]);

                            int stock = findStockById(id, stocksStr);
                            availableItems.add(new Items(id, name, desc, price, stock));
                        }
                    }
                }
            } else {
                initializeAvailableItems();
            }
        } catch (Exception e) {
            Log.e("Driver", "Error loading products data", e);
            initializeAvailableItems();
        }
    }

    public int findStockById(int id, String stocksStr) {
        try {
            if (!stocksStr.isEmpty()) {
                String[] stocks = stocksStr.split(";");
                for (String stock : stocks) {
                    if (!stock.isEmpty()) {
                        String[] parts = stock.split(",");
                        if (parts.length >= 2 && Integer.parseInt(parts[0]) == id) {
                            return Integer.parseInt(parts[1]);
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e("Driver", "Error finding stock by ID", e);
        }
        return 10; // Default stock
    }

    // ================= Core Functions =================
    public boolean addToCart(Items item, int quantity) {
        try {
            if (item == null || quantity <= 0) {
                return false;
            }

            Items availableItem = findItemById(item.getId());
            if (availableItem == null || availableItem.getStockQuantity() < quantity) {
                return false;
            }

            availableItem.decreaseStock(quantity);
            Items cartItem = new Items(item);
            cartItem.setQuantity(quantity);
            currentChoices.addItem(cartItem);

            saveProductsData();
            saveCartData();
            return true;
        } catch (Exception e) {
            Log.e("Driver", "Error adding to cart", e);
            return false;
        }
    }

    public boolean removeFromCart(Items item) {
        try {
            if (item == null) {
                return false;
            }

            boolean removed = currentChoices.removeItem(item);
            if (removed) {
                Items availableItem = findItemById(item.getId());
                if (availableItem != null) {
                    availableItem.increaseStock(item.getQuantity());
                }
                saveProductsData();
                saveCartData();
            }
            return removed;
        } catch (Exception e) {
            Log.e("Driver", "Error removing from cart", e);
            return false;
        }
    }

    public boolean completePurchase() {
        try {
            if (currentChoices.isEmpty() || currentUser == null) {
                return false;
            }

            Order newOrder = new Order(currentChoices.getSelectedItems(), currentUser);
            newOrder.completeOrder();
            orders.add(newOrder);
            currentChoices.clear();
            saveCartData();
            saveProductsData();
            return true;
        } catch (Exception e) {
            Log.e("Driver", "Error completing purchase", e);
            return false;
        }
    }

    // ================= Getters =================
    public List<Items> getCartItems() {
        return new ArrayList<>(currentChoices.getSelectedItems());
    }

    public int getCartItemCount() {
        return currentChoices.getTotalItemsCount();
    }

    public double getCartTotal() {
        return currentChoices.calculateTotalPrice();
    }

    public List<Order> getOrderHistory() {
        return new ArrayList<>(orders);
    }

    public Order getLastOrder() {
        return orders.isEmpty() ? null : orders.get(orders.size() - 1);
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public List<Items> getAvailableItems() {
        return new ArrayList<>(availableItems);
    }

    // ================= Helper Methods =================
    public void initializeAvailableItems() {
        availableItems.clear();

        // Skin care products
        availableItems.add(new Items(1, "كريم مرطب للبشرة", "كريم مرطب عميق للبشرة الجافة", 20.0, 10));
        availableItems.add(new Items(2, "مقشر طبيعي", "مقشر لطيف للبشرة الحساسة", 15.0, 15));
        availableItems.add(new Items(3, "غسول بيبي باودر", "غسول لطيف للأطفال والكبار", 15.0, 20));

        // Lip care products
        availableItems.add(new Items(4, "مرطب شفاه", "مرطب شفاه بخلاصة الفواكه", 10.0, 30));
        availableItems.add(new Items(5, "لمعان شفاه", "لمعان شفاه طويل الأمد", 12.0, 25));
        availableItems.add(new Items(6, "قلم تحديد الشفاه", "قلم دقيق لتحديد الشفاه", 15.0, 15));

        // Perfumes
        availableItems.add(new Items(7, "عطر لطافة", "عطر ناعم ورقيق", 12.0, 20));
        availableItems.add(new Items(8, "عطر صبايا", "عطر شبابي منعش", 12.0, 20));
        availableItems.add(new Items(9, "عطر وشوشة", "عطر ذو رائحة قوية", 15.0, 15));

        saveProductsData();
    }

    public Items findItemByName(String name) {
        if (name == null || name.isEmpty()) {
            return null;
        }

        for (Items item : availableItems) {
            if (name.equals(item.getName())) {
                return item;
            }
        }
        return null;
    }

    public Items findItemById(int id) {
        for (Items item : availableItems) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }

    public List<Items> getItemsByCategory(String category) {
        List<Items> filteredItems = new ArrayList<>();
        for (Items item : availableItems) {
            if (getProductCategory(item.getId()).equals(category)) {
                filteredItems.add(item);
            }
        }
        return filteredItems;
    }

    public List<Items> searchProducts(String query) {
        List<Items> results = new ArrayList<>();
        if (query == null || query.isEmpty()) {
            return results;
        }

        String lowerQuery = query.toLowerCase();
        for (Items item : availableItems) {
            if (item.getName().toLowerCase().contains(lowerQuery) ||
                    item.getDescription().toLowerCase().contains(lowerQuery)) {
                results.add(item);
            }
        }
        return results;
    }

    public String getProductCategory(int productId) {
        if (productId >= 1 && productId <= 3) return "skin_care";
        if (productId >= 4 && productId <= 6) return "lip_care";
        if (productId >= 7 && productId <= 9) return "perfume";
        return "unknown";
    }

    public void clearAllData() {
        try {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear().apply();
            availableItems.clear();
            currentChoices.clear();
            orders.clear();
            currentUser = null;
            initializeAvailableItems();
        } catch (Exception e) {
            Log.e("Driver", "Error clearing all data", e);
        }
    }
    public double calculateTotal() {
        double total = 0.0;

        try {
            if (currentChoices == null) {
                Log.w("Driver", "currentChoices is null in calculateTotal");
                return total;
            }

            List<Items> cartItems = new ArrayList<>(currentChoices.getSelectedItems());

            for (Items item : cartItems) {
                if (item != null) {
                    if (item.getPrice() >= 0 && item.getQuantity() > 0) {
                        total += item.getPrice() * item.getQuantity();
                    } else {
                        Log.w("Driver", "Invalid item price or quantity: " + item.getName());
                    }
                }
            }

            total = Math.round(total * 100.0) / 100.0;

        } catch (Exception e) {
            Log.e("Driver", "Error calculating total", e);
        }

        return total;
    }
}