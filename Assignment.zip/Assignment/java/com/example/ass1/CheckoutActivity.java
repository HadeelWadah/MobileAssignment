package com.example.ass1;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.Locale;

public class CheckoutActivity extends AppCompatActivity {

    private Driver driver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize Driver with application context
        driver = Driver.getInstance(getApplicationContext());

        // Create main scrollable layout
        ScrollView scrollView = new ScrollView(this);
        LinearLayout mainLayout = createMainLayout();
        scrollView.addView(mainLayout);
        setContentView(scrollView);

        // Add title
        mainLayout.addView(createTitleView());

        // Create products container
        LinearLayout productsContainer = createProductsContainer();
        mainLayout.addView(productsContainer);

        // Display cart items and calculate total
        double total = displayCartItems(productsContainer);

        // Add total price view
        mainLayout.addView(createTotalPriceView(total));

        // Add confirm button
        Button confirmButton = createConfirmButton();
        mainLayout.addView(confirmButton);

        // Create confirmation layout (initially hidden)
        LinearLayout confirmationLayout = createConfirmationLayout();
        TextView orderDetails = createOrderDetailsTextView();
        confirmationLayout.addView(createConfirmationTitle());
        confirmationLayout.addView(orderDetails);

        Button newOrderButton = createNewOrderButton();
        confirmationLayout.addView(newOrderButton);
        mainLayout.addView(confirmationLayout);

        // Set up button click listeners
        setupButtonListeners(confirmButton, confirmationLayout, productsContainer, orderDetails, newOrderButton);
    }

    private LinearLayout createMainLayout() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        return layout;
    }

    private TextView createTitleView() {
        TextView title = new TextView(this);
        title.setText("سلة التسوق");
        title.setTextSize(24);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        return title;
    }

    private LinearLayout createProductsContainer() {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(Color.parseColor("#f5f5f5"));
        container.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, dpToPx(16), 0, 0);
        container.setLayoutParams(params);

        return container;
    }

    private TextView createTotalPriceView(double total) {
        TextView totalPrice = new TextView(this);
        totalPrice.setText(String.format(Locale.getDefault(), "المجموع الكلي: %.2f ر.س", total));
        totalPrice.setTextSize(18);
        totalPrice.setTypeface(totalPrice.getTypeface(), android.graphics.Typeface.BOLD);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, dpToPx(16), 0, 0);
        totalPrice.setLayoutParams(params);

        return totalPrice;
    }

    private Button createConfirmButton() {
        Button button = new Button(this);
        button.setText("تأكيد الشراء");
        button.setBackgroundColor(Color.parseColor("#4CAF50"));
        button.setTextColor(Color.WHITE);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, dpToPx(24), 0, 0);
        button.setLayoutParams(params);

        return button;
    }

    private LinearLayout createConfirmationLayout() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#E8F5E9"));
        layout.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        layout.setVisibility(View.GONE);
        return layout;
    }

    private TextView createConfirmationTitle() {
        TextView title = new TextView(this);
        title.setText("تم تأكيد طلبك!");
        title.setTextSize(20);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        return title;
    }

    private TextView createOrderDetailsTextView() {
        TextView textView = new TextView(this);
        textView.setPadding(0, dpToPx(16), 0, 0);
        textView.setLineSpacing(1.5f, 1.5f);
        return textView;
    }

    private Button createNewOrderButton() {
        Button button = new Button(this);
        button.setText("إنهاء");

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, dpToPx(16), 0, 0);
        button.setLayoutParams(params);

        return button;
    }

    private void setupButtonListeners(Button confirmButton, LinearLayout confirmationLayout,
                                      LinearLayout productsContainer, TextView orderDetails,
                                      Button newOrderButton) {
        confirmButton.setOnClickListener(v -> {
            try {
                if (driver.getCartItems().isEmpty()) {
                    Toast.makeText(this, "عربة التسوق فارغة", Toast.LENGTH_SHORT).show();
                    return;
                }

                confirmButton.setVisibility(View.GONE);
                showOrderConfirmation(productsContainer, orderDetails);
                confirmationLayout.setVisibility(View.VISIBLE);

                // Clear cart after successful purchase
                driver.clearCart();
            } catch (Exception e) {
                Log.e("CheckoutActivity", "Error during checkout", e);
                Toast.makeText(this, "حدث خطأ أثناء عملية الشراء", Toast.LENGTH_SHORT).show();
            }
        });

        newOrderButton.setOnClickListener(v -> finish());
    }

    private double displayCartItems(LinearLayout container) {
        container.removeAllViews();
        double total = 0.0;

        try {
            List<Items> cartItems = driver.getCartItems();

            if (cartItems.isEmpty()) {
                TextView emptyText = new TextView(this);
                emptyText.setText("عربة التسوق فارغة");
                emptyText.setTextSize(16);
                emptyText.setGravity(Gravity.CENTER);
                container.addView(emptyText);
                return total;
            }

            for (Items item : cartItems) {
                if (item != null) {
                    total += addCartItemView(container, item);
                }
            }
        } catch (Exception e) {
            Log.e("CheckoutActivity", "Error displaying cart items", e);
        }

        return Math.round(total * 100.0) / 100.0; // Round to 2 decimal places
    }

    private double addCartItemView(LinearLayout container, Items item) {
        LinearLayout itemLayout = new LinearLayout(this);
        itemLayout.setOrientation(LinearLayout.VERTICAL);
        itemLayout.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        itemLayout.setBackgroundColor(Color.WHITE);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, dpToPx(8));
        itemLayout.setLayoutParams(params);

        // Add product name
        TextView name = new TextView(this);
        name.setText(item.getName());
        name.setTextSize(16);
        itemLayout.addView(name);

        // Add price and quantity layout
        LinearLayout priceQtyLayout = new LinearLayout(this);
        priceQtyLayout.setOrientation(LinearLayout.HORIZONTAL);

        TextView price = new TextView(this);
        price.setText(String.format(Locale.getDefault(), "السعر: %.2f ر.س", item.getPrice()));
        price.setLayoutParams(new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1
        ));

        TextView quantity = new TextView(this);
        quantity.setText(String.format(Locale.getDefault(), "الكمية: %d", item.getQuantity()));

        priceQtyLayout.addView(price);
        priceQtyLayout.addView(quantity);
        itemLayout.addView(priceQtyLayout);

        container.addView(itemLayout);

        return item.getPrice() * item.getQuantity();
    }

    private void showOrderConfirmation(LinearLayout productsContainer, TextView orderDetails) {
        try {
            StringBuilder confirmationMessage = new StringBuilder();
            confirmationMessage.append("المنتجات المشتراة:\n\n");

            for (Items item : driver.getCartItems()) {
                confirmationMessage.append("- ")
                        .append(item.getName())
                        .append(" (")
                        .append(item.getQuantity())
                        .append(" × ")
                        .append(String.format(Locale.getDefault(), "%.2f ر.س", item.getPrice()))
                        .append(")\n");
            }

            confirmationMessage.append("\nالمجموع النهائي: ")
                    .append(String.format(Locale.getDefault(), "%.2f ر.س", driver.calculateTotal()));

            orderDetails.setText(confirmationMessage.toString());
            productsContainer.removeAllViews();
        } catch (Exception e) {
            Log.e("CheckoutActivity", "Error showing order confirmation", e);
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (driver.getCartItems().isEmpty()) {
            finish();
        }
    }
}